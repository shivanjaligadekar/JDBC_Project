package example.java.entity;

public class Customer {
	private int customer;
	private String name;
	private String address;
	public Customer() {
		//TODO Auto-generate constructor stub
	}
	public Customer(int customer, String name, String address) {
		super();
		this.customer = customer;
		this.name = name;
		this.address = address;
	}
	public int getCustomer() {
		return customer;
	}
	public void setCustomer(int customer) {
		this.customer = customer;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customer=" + customer + ", name=" + name + ", address=" + address + "]";
	}
	

}

